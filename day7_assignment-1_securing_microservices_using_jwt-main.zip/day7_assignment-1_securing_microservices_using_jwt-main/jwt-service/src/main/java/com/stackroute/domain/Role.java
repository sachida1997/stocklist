package com.stackroute.domain;

public enum Role {
    ADMIN,
    USER
}
