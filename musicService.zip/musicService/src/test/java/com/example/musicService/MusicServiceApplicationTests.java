package com.example.musicService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
