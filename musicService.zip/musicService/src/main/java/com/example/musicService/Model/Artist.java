package com.example.musicService.Model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Artist {
    private Source source;
    private String artistName;
    private String title;
    private String description;
    private String url;
    private String urlToImage;
    private String publishedAt;
}
