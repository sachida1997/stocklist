package com.example.musicService.Model;

import lombok.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Music {
    private String status;
    private int totalResults;
    private List<Artist> artists;
}
