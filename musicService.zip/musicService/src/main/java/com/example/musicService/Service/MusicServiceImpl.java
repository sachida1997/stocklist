package com.example.musicService.Service;


import com.example.musicService.Model.Music;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MusicServiceImpl implements MusicService {
    //add your api key here
    private static final String API_KEY = "662fe35159ee42a0a0e46ee4aaed2f0d";

    //add the base api url here
    private static final String API_URL = "https://newsapi.org/v2/everything?q=";

    private final RestTemplate restTemplate;
    public MusicServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    //using rest template, get the music details
    @Override
    public Music getMusicArtist() {
        return null;
    }

    @Override
    public Music getMusic(String q) {
        String musicUrl = API_URL  + q + "&apiKey=" + API_KEY;
        // System.out.println("Music Url:"+MusicUrl);
        return restTemplate.getForObject(musicUrl,Music.class);
    }
}
