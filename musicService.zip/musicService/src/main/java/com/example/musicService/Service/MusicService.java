package com.example.musicService.Service;

import com.example.musicService.Model.Music;

public interface MusicService {
    Music getMusicArtist();
    Music getMusic(String q);
}
