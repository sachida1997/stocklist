package com.SpotifyApp.UserProfile.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.SpotifyApp.UserProfile.Entity.User;

public interface UserRepo extends JpaRepository<User, Long>{
	

}
