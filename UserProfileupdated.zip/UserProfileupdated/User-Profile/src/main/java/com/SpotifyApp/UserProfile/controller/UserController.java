package com.SpotifyApp.UserProfile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SpotifyApp.UserProfile.Entity.User;
import com.SpotifyApp.UserProfile.service.UserService;

@RestController
@RequestMapping("/user/v1")
public class UserController {
	
	@Autowired
	private UserService userservice;
	
	//add user
	@PostMapping("/saveUser")
	public ResponseEntity<User> saveUser(@RequestBody User user){
	 return new ResponseEntity<>(userservice.saveUser(user),HttpStatus.CREATED);

}
   //Update User
	@PutMapping("/updateUser")
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable("id") long id){
		return new ResponseEntity<>(userservice.updateUer(user),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteUser")
	public ResponseEntity<User> deleteUser(@PathVariable("id")Long id){
		return new ResponseEntity<>(userservice.deleteUser(id),HttpStatus.OK);
	}
	
	

}
