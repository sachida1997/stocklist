package com.SpotifyApp.UserProfile.service;

import org.springframework.http.ResponseEntity;

import com.SpotifyApp.UserProfile.Entity.User;

  public interface UserService {
       User saveUser(User user);
       User updateUer(User user);
       User deleteUser(Long id);
       
       
       
       
       
       
       
	}

	

