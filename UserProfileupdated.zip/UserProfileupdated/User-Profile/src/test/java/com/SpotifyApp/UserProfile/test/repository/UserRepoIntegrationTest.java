package com.SpotifyApp.UserProfile.test.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.SpotifyApp.UserProfile.Entity.User;
import com.SpotifyApp.UserProfile.repository.UserRepo;

@SpringBootTest
public class UserRepoIntegrationTest {
	
	@Autowired
	private UserRepo userrepo;
	private User user;
	
	@BeforeEach
	public void setup() {
		user= new User();
		user.setId(1);
		user.setMobile(999999999);
		user.setFirstname("tom");
		user.setLastname("jerry");
		user.setEmailid("tom@gmail.com");	
	}
	@AfterEach
	public void tearDown() {
		userrepo= null;
	}
	
	public void givenUserToSaveShouldReturnSaveUser() {
		userrepo.save(user);
		User fetcheduser = userrepo.findById(user.getId()).get();
		assertEquals(1,fetcheduser.getId());
	}
	
	public void givenIdToDeleteThenShouldReturnDeletedUser() {
		User user = new User();
		user.setId(2);
		user.setMobile(898989898);
		user.setFirstname("chota");
		user.setLastname("bheem");
		user.setEmailid("chota@gmail.com");
		userrepo.save(user);
		userrepo.deleteById(user.getId());
		 Optional optional = userrepo.findById(user.getId());
	        assertEquals(Optional.empty(), optional);
	}
	
	
	
	
	

}
